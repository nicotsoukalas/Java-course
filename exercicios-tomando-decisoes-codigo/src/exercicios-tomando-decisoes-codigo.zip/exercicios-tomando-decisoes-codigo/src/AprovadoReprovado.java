import java.util.Scanner;

/*
 * Leia 3 notas de um aluno e imprima se ele foi aprovado ou não.
 * Obs: O aluno deve possuir média 7.0 ou maior para ser aprovado.
 */
public class AprovadoReprovado {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Informe 3 notas:");
    double nota1 = scanner.nextDouble();
    double nota2 = scanner.nextDouble();
    double nota3 = scanner.nextDouble();

    double media = (nota1 + nota2 + nota3) / 3;

    if (media >= 7.0)
      System.out.println("APROVADO! :)");
    else
      System.out.println("REPROVADO! :(");

    scanner.close();
  }
}
