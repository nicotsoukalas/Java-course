import java.util.Scanner;

/*
 * Crie uma calculadora que dados 2 números e uma operação 
 * (adição, subtração, multiplicação ou divisão), retorne o 
 * resultado dessa operação entre os dois números.
 * 
 * Ex: 
 *   1 2 * => 1 * 2 = 2
 *   8 2 / => 8 / 2 = 4
 */
public class Calculadora {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Digite 2 números:");
    int numero1 = scanner.nextInt();
    int numero2 = scanner.nextInt();
    
    System.out.println("Digite a operação (+, -, *, /):");
    String operador = scanner.next();

    switch(operador) {
      case "+" -> System.out.printf("%d %s %d = %d", 
        numero1, operador, numero2, numero1 + numero2);
      case "-" -> System.out.printf("%d %s %d = %d", 
        numero1, operador, numero2, numero1 - numero2);
      case "*" -> System.out.printf("%d %s %d = %d", 
        numero1, operador, numero2, numero1 * numero2);
      case "/" -> System.out.printf("%d %s %d = %d", 
        numero1, operador, numero2, numero1 / numero2);
      default -> System.out.println("Operador inválido!");
    }

    scanner.close();
  }
}
