/*
 * Contando de 1 a 10. 
 */
public class Exercise1 {
  public static void main(String[] args) {
    int number = 1;
    while (number <= 10) {
      System.out.println(number);
      number++;
    }
  }
}
