public class Compra {
  String produto;
  double valor;
  int quantidade;
}
