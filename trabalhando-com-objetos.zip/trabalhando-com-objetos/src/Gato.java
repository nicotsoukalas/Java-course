public class Gato {
  public String nome;

  public Gato(String nome) {
    this.nome = nome;
  }

  public String toString() {
    return "{ nome: " + this.nome + " }";
  }
}
