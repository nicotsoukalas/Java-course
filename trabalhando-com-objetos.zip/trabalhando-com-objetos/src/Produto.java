public class Produto {
  String name;
  String description;
  int estoque;
}
